#ifndef RTLSDATAPROCESS_H
#define RTLSDATAPROCESS_H

#include <QObject>
#include <QDebug>
#include <QDomElement>
#include "SerialConnection.h"
#include "RTLSDisplayApplication.h"
#include "trilateration.h"

typedef struct
{
    double x_arr[50];
    double y_arr[50];
    double z_arr[50];

    double std_x, std_y, std_z;

    qint8 id;
    int arr_idx;
    int rangeSeq;
    int rangeValue[256][4]; //(mm) each tag ranges to 4 anchors - it has a range number which is modulo 256
} tag_reports_t;

#define MAX_NUM_TAGS (255)
#define MAX_NUM_ANCS (255)

typedef struct
{
    double x, y, z;
    quint8 id;
    QString label;
} anc_struct_t;

typedef struct
{
  double x;
  double y;
} vec2d;



class RTLSDataProcess : public QObject
{
    Q_OBJECT
public:
    explicit RTLSDataProcess(QObject *parent = 0);

    void initializeTagList(int id);
    void parseTagCoordinateReport(quint8 aid[4], qint32 range[4], quint8 tid);
    int calculateTagLocation(vec3d *tag_coord, quint8 aid[4], int range[4]);
    void addMissingAnchors(void);
    void loadConfigFile(QString filename);
    void saveConfigFile(QString filename);
    QDomElement AnchorToNode(QDomDocument &d, anc_struct_t *anc);

signals:
    void onTagPositionUpdated(quint8 tagId, double x, double y, double z);
    void onAnchorPositionUpdated(int row_id, quint8 row_idx, double x, double y, double z, bool show, bool update);
    void statusBarMessage(QString status);
public slots:
    void onReady();
    void newData();
    void connectionStateChanged(SerialConnection::ConnectionState state);
    void updateAnchorCoordinate(int row_idx, int dim, double value);
private:
    QSerialPort *_serial;

    QList<tag_reports_t> _tagList;//储存tag的list

    QList<anc_struct_t> _ancList;//储存anchor的list
};

#endif // RTLSDATAPROCESS_H
