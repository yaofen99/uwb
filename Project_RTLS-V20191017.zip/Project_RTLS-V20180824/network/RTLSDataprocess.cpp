#include "RTLSDataprocess.h"
#include <QFile>
#include <QDomNode>

RTLSDataProcess::RTLSDataProcess(QObject *parent) : QObject(parent)
{
    _serial = RTLSDisplayApplication::serialConnection()->serialPort();
    RTLSDisplayApplication::connectReady(this, "onReady()");
}


void RTLSDataProcess::onReady()
{
    QObject::connect(_serial, SIGNAL(readyRead()), this, SLOT(newData()));
    qDebug() << "/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/";
}

//初始化TagReport结构体,并把它添加到tagList中
void RTLSDataProcess::initializeTagList(int id)
{
    tag_reports_t r;
    memset(&r, 0, sizeof(tag_reports_t));
    r.id = id;

    r.rangeSeq = - 1;
    memset(&r.rangeValue[0][0], - 1, sizeof(r.rangeValue));
    _tagList.append(r);
}

//数据缓冲区
static QByteArray data_buffer;//静态全局变量！！在串口只发送一半的时候用来累加数据
bool sLock = false;

void RTLSDataProcess::newData()
{
    qDebug() << "执行了newData";
    if(0/*sLock*/) {//正在处理数据中
        return;
    } else {
        sLock = true;

        if(_serial->bytesAvailable() > 0) {
            data_buffer += _serial->readAll();
        }
        int length = data_buffer.length();
        while(length >= 53) {//该缓冲区中有52个字节及以上的数据（即含有一帧数据对应的字节数），就对其做解析
            qDebug() << "执行了>53";
            QByteArray header = data_buffer.left(2);
            if(! header.contains("mc")) {
                data_buffer.remove(0, 1);//删掉data_buffer中最先进来的一个字节
            } else {
                qDebug() << "执行了判断 mc";
                quint8 aid[4], tid;
                int range[4];
                int ret = sscanf(data_buffer.constData(), "mc %1c %x %1c %x %1c %x %1c %x a %1c ", &aid[0], &range[0], &aid[1], &range[1], &aid[2], &range[2], &aid[3], &range[3], &tid);
                if(ret == 9) {//如果sscanf提取出来的参数个数为9，说明数据提取成功

                    parseTagCoordinateReport(aid, range, tid);//解析标签坐标帧数据
                    //emit ;//触发ui更新
                }
                data_buffer.remove(0, 53);//处理完后删掉这一帧
            }
            length = data_buffer.length();
        }

        sLock = true;
    }
}

void RTLSDataProcess::parseTagCoordinateReport(quint8 aid[4], qint32 range[4], quint8 tid)
{
    vec3d tag_coord;//标签坐标

    quint8 idx = 0;
    //在tagList中查找tid对应的Tag数据结构
    for(idx = 0; idx < _tagList.size(); idx++)
    {
        //find this tag in the list
        if(_tagList.at(idx).id == tid)
            break;
    }

    //如果没有找到，就创建一个
    if(idx == _tagList.size()) {
        initializeTagList(tid);
    }

    if(calculateTagLocation(&tag_coord, aid, range) == TRIL_3SPHERES) {//如果有解
//        newposition = true;
//        rp.numberOfLEs++;

        qDebug() << "解算出来的坐标为：" << tag_coord.x << tag_coord.y << tag_coord.z;
        emit onTagPositionUpdated(tid, tag_coord.x, tag_coord.y, tag_coord.z);//更新ui

    } else {
        qDebug() << "坐标无解";
    }
}

void ExchangeCoordinate(int index, vec3d *srcArray, vec3d *anchorArray, int *range_src, int *range)//交换坐标
{
    switch(index) {
    case 0:
        //什么 都不需要做，因为直接取前三个坐标就行了
        break;
    case 1:
        anchorArray[0].x = srcArray[3].x;
        anchorArray[0].y = srcArray[3].y;
        anchorArray[0].z = srcArray[3].z;
        anchorArray[1].x = srcArray[1].x;
        anchorArray[1].y = srcArray[1].y;
        anchorArray[1].z = srcArray[1].z;
        anchorArray[2].x = srcArray[2].x;
        anchorArray[2].y = srcArray[2].y;
        anchorArray[2].z = srcArray[2].z;
        range[0] = range_src[3];
        range[1] = range_src[1];
        range[2] = range_src[2];

        break;
    case 2:
        anchorArray[1].x = srcArray[3].x;
        anchorArray[1].y = srcArray[3].y;
        anchorArray[1].z = srcArray[3].z;
        anchorArray[0].x = srcArray[0].x;
        anchorArray[0].y = srcArray[0].y;
        anchorArray[0].z = srcArray[0].z;
        anchorArray[2].x = srcArray[2].x;
        anchorArray[2].y = srcArray[2].y;
        anchorArray[2].z = srcArray[2].z;
        range[1] = range_src[3];
        range[0] = range_src[0];
        range[2] = range_src[2];

        break;
    case 3:
        anchorArray[2].x = srcArray[3].x;
        anchorArray[2].y = srcArray[3].y;
        anchorArray[2].z = srcArray[3].z;
        anchorArray[0].x = srcArray[0].x;
        anchorArray[0].y = srcArray[0].y;
        anchorArray[0].z = srcArray[0].z;
        anchorArray[1].x = srcArray[1].x;
        anchorArray[1].y = srcArray[1].y;
        anchorArray[1].z = srcArray[1].z;
        range[2] = range_src[3];
        range[0] = range_src[0];
        range[1] = range_src[1];

        break;
    }
}

int RTLSDataProcess::calculateTagLocation(vec3d *tag_coord, quint8 aid[4], int range[4])
{
    int result = 0;
    vec3d anchorArray[4];

    quint8 idx[4] = { 0 };
    for(quint8 i = 0; i < 4; i++) {
        for(idx[i] = 0; idx[i] < _ancList.size(); idx[i]++) {
            if(_ancList.at(idx[i]).id == aid[i])
                break;
        }

        if(idx[i] == _ancList.size()) {
            qDebug() << "基站id不存在！";
            return - 1;
        }
        anchorArray[i].x = _ancList[idx[i]].x;
        anchorArray[i].y = _ancList[idx[i]].y;
        anchorArray[i].z = _ancList[idx[i]].z;
    }


    result = GetLocation(tag_coord, 1, &anchorArray[0], range);
    vec3d anchor_copy[4];
    for(int i = 0; i < 4; i++) {
        anchor_copy[i].x = anchorArray[i].x;
        anchor_copy[i].y = anchorArray[i].y;
        anchor_copy[i].z = anchorArray[i].z;
    }
    int range_copy[4];
    for(int i = 0; i < 4; i++) {
        range_copy[i] = range[i];
    }

    for(int i = 0; i < 4; i++) {
        ExchangeCoordinate(i, anchor_copy, anchorArray, range_copy, range);//交换坐标
        if(result != TRIL_3SPHERES) {
            qDebug() << "第" << i << "次" << "交换坐标";
            qDebug() << "坐标为:" << anchorArray[0].x << ':' << anchorArray[0].y << ':' << anchorArray[0].z;
            qDebug() << "坐标为:" << anchorArray[1].x << ':' << anchorArray[1].y << ':' << anchorArray[1].z;
            qDebug() << "坐标为:" << anchorArray[2].x << ':' << anchorArray[2].y << ':' << anchorArray[2].z;
            result = GetLocation(tag_coord, 0, &anchorArray[0], range);
            qDebug() << "result:" << result;
        } else {
            return result;
        }
    }
    return result;
}

void RTLSDataProcess::updateAnchorCoordinate(int row_idx, int dim, double value)
{
    if(row_idx >= _ancList.size()) {
        return;
    }
    if(dim == 0) {
        _ancList[row_idx].id = (quint8)value;
    } else if(dim == 1) {
        _ancList[row_idx].x = value;
    } else if (dim == 2) {
        _ancList[row_idx].y = value;
    } else if (dim == 3) {
        _ancList[row_idx].z = value;
    }

}

void RTLSDataProcess::connectionStateChanged(SerialConnection::ConnectionState state)
{
    qDebug() << "RTLSDataProcess::connectionStateChanged " << state;

    if(state == SerialConnection::Disconnected) {//disconnect from Serial Port
        if(_serial != NULL) {
            disconnect(_serial, SIGNAL(readyRead()), this, SLOT(newData()));
            _serial = NULL;
        }
//        if(_file) {
//            _file->close(); //close the Log file
//        }
    }

}

double coord[9][3] = {
    {0, 0, 2},
    {8, 0, 2},
    {0, 8, 2},
    {8, 8, 2},
    {4, 0, 2},
    {0, 4, 2},
    {4, 4, 2},
    {4, 8, 2},
    {8, 4, 2},
};

void RTLSDataProcess::addMissingAnchors(void)
{
    for(int i = 0; i < 9; i++) {
        anc_struct_t anc;
        anc.id = i + '0';
        anc.label = "df";
        anc.x = coord[i][0];
        anc.y = coord[i][1];
        anc.z = coord[i][2];
        _ancList.append(anc);

        emit onAnchorPositionUpdated(i, anc.id, anc.x, anc.y, anc.z, false, false);

    }

    //emit centerOnAnchors();
}

void RTLSDataProcess::loadConfigFile(QString filename)
{
    qDebug() << "执行到了1！";
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug(qPrintable(QString("Error: Cannot read file %1 %2").arg(filename).arg(file.errorString())));
        return;
    }

/*
    addMissingAnchors();
    return;
*/

    QDomDocument doc;
    QString error;
    int errorLine;
    int errorColumn;

    if(doc.setContent(&file, false, &error, &errorLine, &errorColumn)) {
        qDebug() << "file error !!!" << error << errorLine << errorColumn;
    }

    QDomElement config = doc.documentElement();

    qDebug() << "执行到了2！";
    if(config.tagName() == "config")
    {
        int cnt = 0;
        QDomNode n = config.firstChild();
        while(! n.isNull()) {
            QDomElement e = n.toElement();
            qDebug() << "执行到了3！";
            if(! e.isNull()) {
                if(e.tagName() == "anc") {
                    bool ok;
                    int id = (e.attribute( "ID", "0" )).toInt(&ok);

                    id &= 0xff;

                    if(ok) {
                        qDebug() << "执行到了4！";
                        anc_struct_t anc_;
                        anc_.id = id & 0xff;
                        anc_.label = (e.attribute("label", ""));
                        anc_.x = (e.attribute("x", "0.0")).toDouble(&ok);
                        anc_.y = (e.attribute("y", "0.0")).toDouble(&ok);
                        anc_.z = (e.attribute("z", "0.0")).toDouble(&ok);


                        _ancList.append(anc_);

                        emit onAnchorPositionUpdated(cnt, anc_.id, anc_.x, anc_.y, anc_.z, true, false);
                    }
                }
            }
            cnt++;
            if(cnt > 255) {
                cnt = 255;
                break;
            }
            n = n.nextSibling();
        }
    }

    file.close();

    //addMissingAnchors();
}


void RTLSDataProcess::saveConfigFile(QString filename)
{
    QFile file(filename);
    if (!file.open(QFile::ReadWrite | QFile::Text | QFile::Truncate)) {
        qDebug(qPrintable(QString("Error: Cannot read file %1 %2").arg(filename).arg(file.errorString())));
        return;
    }

    QDomDocument doc;

    // Adding tag config root
    QDomElement config = doc.createElement("config");
    doc.appendChild(config);

    for(int i = 0; i < _ancList.size(); i++) {
        config.appendChild(AnchorToNode(doc, &_ancList[i]));
    }

    QTextStream ts(&file);
    ts << doc.toString();

    file.close();

//    if(_file) {
//        _file->flush();
//    }
    qDebug() << doc.toString();
}

QDomElement RTLSDataProcess::AnchorToNode(QDomDocument &d, anc_struct_t *anc)
{
    QDomElement cn = d.createElement("anc");
    cn.setAttribute("ID", QString::number(anc->id));
    cn.setAttribute("label", anc->label);
    cn.setAttribute("x", anc->x);
    cn.setAttribute("y", anc->y);
    cn.setAttribute("z", anc->z);
    return cn;
}
